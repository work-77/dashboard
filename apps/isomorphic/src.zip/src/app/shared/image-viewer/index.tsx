'use client';

import ImageViewer from '@core/components/image-viewer';

export default function ImageViewerTemplate() {
  return <ImageViewer />;
}
