import CrmDashboard from '@/app/shared/crm/dashboard';

export default function CrmDashboardPage() {
  return <CrmDashboard />;
}
