import JobFeed from '@/app/shared/job-board/feeds';

export default function JobFeedPage() {
  return <JobFeed />;
}
