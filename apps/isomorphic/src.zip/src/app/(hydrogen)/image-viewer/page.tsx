import ImageViewerTemplate from '@/app/shared/image-viewer';

export default function ImageViewerPage() {
  return <ImageViewerTemplate />;
}
