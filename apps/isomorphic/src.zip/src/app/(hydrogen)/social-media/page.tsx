import SocialMediaDashboard from '@/app/shared/social-media/dashboard';

export default function SocialMediaDashboardPage() {
  return <SocialMediaDashboard />;
}
